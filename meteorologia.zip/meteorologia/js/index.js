const cidade = document.querySelector("#inputCidade")
const URL = 'https://api.openweathermap.org/data/2.5/weather';
const keyAPI = '6e5b8505b21b69b10124280e2e4f786b';
const unidade = 'metric';
const erro = document.querySelector("#erro")

var contErro = 0

const btnEnviar = document.querySelector("#btnEnviar")

async function pegarClima(cidade){
    const dados = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cidade}&appid=${keyAPI}&units=metric&lang=pt_br`).then(
        (Response) => Response.json()
        .then(erro.classList.add("invisivel"))
    );


    mostrarClima(dados)
    

    
}

function mostrarClima(info){

    if (info.name != undefined) {
        const descricao = info.weather[0].description
        document.getElementById("info").classList.remove("invisivel")
        document.getElementById("imagem").classList.remove("invisivel")

        document.getElementById("cidade").innerHTML = "Clima de " + info.name
        document.getElementById("temperatura").innerHTML = "Temperatura: " + info.main.temp + "° C"
        document.getElementById("nuvens").innerHTML = descricao[0].toUpperCase() + descricao.substring(1);
        document.getElementById("umidade").innerHTML = "Umidade: " + info.main.humidity + "%"
    
        document.getElementById("imagem").src = `https://openweathermap.org/img/wn/${info.weather[0].icon}.png`

    } else{
        erro.classList.remove("invisivel")
    }
   
}


btnEnviar.addEventListener("click", ()=>{

   pegarClima(document.getElementById("inputCidade").value)
    
})
